
DROP INDEX idx_user_profiles_username;
DROP INDEX idx_user_profiles_user_id;
DROP INDEX idx_likes_video_id;
DROP INDEX idx_likes_user_id;
DROP INDEX idx_videos_created_at;
DROP INDEX idx_videos_user_id;
DROP TABLE user_profiles;
DROP TABLE likes;
DROP TABLE videos;
