import z from "zod";

export const VideoSchema = z.object({
  id: z.number(),
  user_id: z.string(),
  title: z.string().nullable(),
  description: z.string().nullable(),
  video_url: z.string(),
  thumbnail_url: z.string().nullable(),
  duration_seconds: z.number().nullable(),
  view_count: z.number(),
  like_count: z.number(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const LikeSchema = z.object({
  id: z.number(),
  user_id: z.string(),
  video_id: z.number(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const UserProfileSchema = z.object({
  id: z.number(),
  user_id: z.string(),
  username: z.string().nullable(),
  display_name: z.string().nullable(),
  bio: z.string().nullable(),
  avatar_url: z.string().nullable(),
  follower_count: z.number(),
  following_count: z.number(),
  video_count: z.number(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const CreateVideoSchema = z.object({
  title: z.string().optional(),
  description: z.string().optional(),
  video_url: z.string(),
  thumbnail_url: z.string().optional(),
  duration_seconds: z.number().optional(),
});

export const UpdateProfileSchema = z.object({
  username: z.string().optional(),
  display_name: z.string().optional(),
  bio: z.string().optional(),
  avatar_url: z.string().optional(),
});

export type Video = z.infer<typeof VideoSchema>;
export type Like = z.infer<typeof LikeSchema>;
export type UserProfile = z.infer<typeof UserProfileSchema>;
export type CreateVideo = z.infer<typeof CreateVideoSchema>;
export type UpdateProfile = z.infer<typeof UpdateProfileSchema>;

export interface VideoWithProfile extends Video {
  profile: UserProfile;
  is_liked: boolean;
}
