import { Hono } from "hono";
import { cors } from "hono/cors";
import { zValidator } from "@hono/zod-validator";
import {
  exchangeCodeForSessionToken,
  getOAuthRedirectUrl,
  authMiddleware,
  deleteSession,
  MOCHA_SESSION_TOKEN_COOKIE_NAME,
} from "@getmocha/users-service/backend";
import { getCookie, setCookie } from "hono/cookie";
import { CreateVideoSchema, UpdateProfileSchema } from "@/shared/types";

const app = new Hono<{ Bindings: Env }>();

app.use("*", cors({
  origin: ["http://localhost:5173"],
  credentials: true,
}));

// Auth routes
app.get('/api/oauth/google/redirect_url', async (c) => {
  const redirectUrl = await getOAuthRedirectUrl('google', {
    apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
    apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
  });

  return c.json({ redirectUrl }, 200);
});

app.post("/api/sessions", async (c) => {
  const body = await c.req.json();

  if (!body.code) {
    return c.json({ error: "No authorization code provided" }, 400);
  }

  const sessionToken = await exchangeCodeForSessionToken(body.code, {
    apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
    apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
  });

  setCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME, sessionToken, {
    httpOnly: true,
    path: "/",
    sameSite: "none",
    secure: true,
    maxAge: 60 * 24 * 60 * 60, // 60 days
  });

  return c.json({ success: true }, 200);
});

app.get("/api/users/me", authMiddleware, async (c) => {
  return c.json(c.get("user"));
});

app.get('/api/logout', async (c) => {
  const sessionToken = getCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME);

  if (typeof sessionToken === 'string') {
    await deleteSession(sessionToken, {
      apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
      apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
    });
  }

  setCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME, '', {
    httpOnly: true,
    path: '/',
    sameSite: 'none',
    secure: true,
    maxAge: 0,
  });

  return c.json({ success: true }, 200);
});

// Profile routes
app.get("/api/profiles/:userId", async (c) => {
  const userId = c.req.param("userId");
  
  const profile = await c.env.DB.prepare(
    "SELECT * FROM user_profiles WHERE user_id = ?"
  ).bind(userId).first();

  if (!profile) {
    return c.json({ error: "Profile not found" }, 404);
  }

  return c.json(profile);
});

app.get("/api/profiles", authMiddleware, async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }
  
  let profile = await c.env.DB.prepare(
    "SELECT * FROM user_profiles WHERE user_id = ?"
  ).bind(user.id).first();

  if (!profile) {
    // Create default profile
    const result = await c.env.DB.prepare(
      "INSERT INTO user_profiles (user_id, display_name, avatar_url) VALUES (?, ?, ?) RETURNING *"
    ).bind(
      user.id, 
      user.google_user_data.name || user.email.split('@')[0],
      user.google_user_data.picture
    ).first();
    profile = result;
  }

  return c.json(profile);
});

app.put("/api/profiles", authMiddleware, zValidator("json", UpdateProfileSchema), async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }
  const data = c.req.valid("json");

  const result = await c.env.DB.prepare(
    `UPDATE user_profiles 
     SET username = COALESCE(?, username),
         display_name = COALESCE(?, display_name),
         bio = COALESCE(?, bio),
         avatar_url = COALESCE(?, avatar_url),
         updated_at = CURRENT_TIMESTAMP
     WHERE user_id = ?
     RETURNING *`
  ).bind(data.username, data.display_name, data.bio, data.avatar_url, user.id).first();

  return c.json(result);
});

// Video routes
app.get("/api/videos", async (c) => {
  const page = parseInt(c.req.query("page") || "1");
  const limit = parseInt(c.req.query("limit") || "10");
  const offset = (page - 1) * limit;

  const videos = await c.env.DB.prepare(`
    SELECT v.*, p.username, p.display_name, p.avatar_url
    FROM videos v
    LEFT JOIN user_profiles p ON v.user_id = p.user_id
    ORDER BY v.created_at DESC
    LIMIT ? OFFSET ?
  `).bind(limit, offset).all();

  // Get current user's likes if authenticated
  const user = c.get("user");
  let likedVideoIds: number[] = [];
  
  if (user && videos.results.length > 0) {
    const videoIds = videos.results.map((v: any) => v.id);
    const likes = await c.env.DB.prepare(`
      SELECT video_id FROM likes 
      WHERE user_id = ? AND video_id IN (${videoIds.map(() => '?').join(',')})
    `).bind(user.id, ...videoIds).all();
    
    likedVideoIds = likes.results.map((l: any) => l.video_id);
  }

  const videosWithLikes = videos.results.map((video: any) => ({
    ...video,
    is_liked: likedVideoIds.includes(video.id),
    profile: {
      username: video.username,
      display_name: video.display_name,
      avatar_url: video.avatar_url,
    }
  }));

  return c.json(videosWithLikes);
});

app.post("/api/videos", authMiddleware, zValidator("json", CreateVideoSchema), async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }
  const data = c.req.valid("json");

  const result = await c.env.DB.prepare(
    `INSERT INTO videos (user_id, title, description, video_url, thumbnail_url, duration_seconds)
     VALUES (?, ?, ?, ?, ?, ?)
     RETURNING *`
  ).bind(
    user.id,
    data.title || null,
    data.description || null,
    data.video_url,
    data.thumbnail_url || null,
    data.duration_seconds || null
  ).first();

  // Update user's video count
  await c.env.DB.prepare(
    "UPDATE user_profiles SET video_count = video_count + 1 WHERE user_id = ?"
  ).bind(user.id).run();

  return c.json(result);
});

app.post("/api/videos/:id/like", authMiddleware, async (c) => {
  const user = c.get("user");
  if (!user) {
    return c.json({ error: "Unauthorized" }, 401);
  }
  const videoId = parseInt(c.req.param("id"));

  // Check if already liked
  const existingLike = await c.env.DB.prepare(
    "SELECT id FROM likes WHERE user_id = ? AND video_id = ?"
  ).bind(user.id, videoId).first();

  if (existingLike) {
    // Unlike
    await c.env.DB.prepare(
      "DELETE FROM likes WHERE user_id = ? AND video_id = ?"
    ).bind(user.id, videoId).run();

    await c.env.DB.prepare(
      "UPDATE videos SET like_count = like_count - 1 WHERE id = ?"
    ).bind(videoId).run();

    return c.json({ liked: false });
  } else {
    // Like
    await c.env.DB.prepare(
      "INSERT INTO likes (user_id, video_id) VALUES (?, ?)"
    ).bind(user.id, videoId).run();

    await c.env.DB.prepare(
      "UPDATE videos SET like_count = like_count + 1 WHERE id = ?"
    ).bind(videoId).run();

    return c.json({ liked: true });
  }
});

app.post("/api/videos/:id/view", async (c) => {
  const videoId = parseInt(c.req.param("id"));

  await c.env.DB.prepare(
    "UPDATE videos SET view_count = view_count + 1 WHERE id = ?"
  ).bind(videoId).run();

  return c.json({ success: true });
});

export default app;
