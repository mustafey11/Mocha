import { useRef, useEffect, useState } from "react";
import { Heart, MessageCircle, Share, Play } from "lucide-react";
import { useAuth } from "@getmocha/users-service/react";
import type { VideoWithProfile } from "@/shared/types";

interface VideoPlayerProps {
  video: VideoWithProfile;
  isActive: boolean;
  onUpdateVideo: (video: VideoWithProfile) => void;
}

export default function VideoPlayer({ video, isActive, onUpdateVideo }: VideoPlayerProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isLiking, setIsLiking] = useState(false);
  const { user } = useAuth();

  useEffect(() => {
    const videoElement = videoRef.current;
    if (!videoElement) return;

    if (isActive) {
      videoElement.play().then(() => {
        setIsPlaying(true);
      }).catch(console.error);
      
      // Track view
      fetch(`/api/videos/${video.id}/view`, {
        method: "POST",
        credentials: "include",
      }).catch(console.error);
    } else {
      videoElement.pause();
      setIsPlaying(false);
    }
  }, [isActive, video.id]);

  const togglePlayPause = () => {
    const videoElement = videoRef.current;
    if (!videoElement) return;

    if (isPlaying) {
      videoElement.pause();
      setIsPlaying(false);
    } else {
      videoElement.play().then(() => {
        setIsPlaying(true);
      }).catch(console.error);
    }
  };

  const handleLike = async () => {
    if (!user || isLiking) return;
    
    setIsLiking(true);
    try {
      const response = await fetch(`/api/videos/${video.id}/like`, {
        method: "POST",
        credentials: "include",
      });
      const data = await response.json();
      
      const updatedVideo = {
        ...video,
        is_liked: data.liked,
        like_count: data.liked ? video.like_count + 1 : video.like_count - 1,
      };
      
      onUpdateVideo(updatedVideo);
    } catch (error) {
      console.error("Failed to like video:", error);
    } finally {
      setIsLiking(false);
    }
  };

  const formatCount = (count: number) => {
    if (count >= 1000000) {
      return `${(count / 1000000).toFixed(1)}M`;
    }
    if (count >= 1000) {
      return `${(count / 1000).toFixed(1)}K`;
    }
    return count.toString();
  };

  return (
    <div className="relative w-full h-full bg-black overflow-hidden">
      {/* Video */}
      <video
        ref={videoRef}
        className="w-full h-full object-cover"
        loop
        muted
        playsInline
        poster={video.thumbnail_url || undefined}
        onClick={togglePlayPause}
      >
        <source src={video.video_url} type="video/mp4" />
      </video>

      {/* Play/Pause overlay */}
      {!isPlaying && (
        <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-30">
          <button
            onClick={togglePlayPause}
            className="w-20 h-20 bg-black bg-opacity-50 rounded-full flex items-center justify-center"
          >
            <Play className="w-8 h-8 text-white ml-1" />
          </button>
        </div>
      )}

      {/* Content overlay */}
      <div className="absolute inset-0 flex">
        {/* Left side - video info */}
        <div className="flex-1 flex flex-col justify-end p-4 pb-20">
          <div className="space-y-3">
            {/* User info */}
            <div className="flex items-center space-x-3">
              <img
                src={video.profile.avatar_url || "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face"}
                alt={video.profile.display_name || "User"}
                className="w-12 h-12 rounded-full border-2 border-white"
              />
              <div>
                <p className="font-semibold text-white">
                  {video.profile.display_name || "Unknown User"}
                </p>
                {video.profile.username && (
                  <p className="text-gray-300 text-sm">@{video.profile.username}</p>
                )}
              </div>
            </div>

            {/* Video description */}
            {video.description && (
              <p className="text-white text-sm leading-relaxed max-w-xs">
                {video.description}
              </p>
            )}
          </div>
        </div>

        {/* Right side - actions */}
        <div className="flex flex-col justify-end items-center p-4 pb-20 space-y-6">
          {/* Like button */}
          <div className="flex flex-col items-center">
            <button
              onClick={handleLike}
              disabled={!user || isLiking}
              className={`w-12 h-12 rounded-full flex items-center justify-center transition-all ${
                video.is_liked 
                  ? "bg-red-500 text-white" 
                  : "bg-gray-800 bg-opacity-70 text-white hover:bg-opacity-90"
              } ${isLiking ? "opacity-50" : ""}`}
            >
              <Heart className={`w-6 h-6 ${video.is_liked ? "fill-current" : ""}`} />
            </button>
            <span className="text-white text-xs mt-1">
              {formatCount(video.like_count)}
            </span>
          </div>

          {/* Comment button */}
          <div className="flex flex-col items-center">
            <button className="w-12 h-12 bg-gray-800 bg-opacity-70 rounded-full flex items-center justify-center text-white hover:bg-opacity-90 transition-all">
              <MessageCircle className="w-6 h-6" />
            </button>
            <span className="text-white text-xs mt-1">0</span>
          </div>

          {/* Share button */}
          <div className="flex flex-col items-center">
            <button className="w-12 h-12 bg-gray-800 bg-opacity-70 rounded-full flex items-center justify-center text-white hover:bg-opacity-90 transition-all">
              <Share className="w-6 h-6" />
            </button>
            <span className="text-white text-xs mt-1">Share</span>
          </div>
        </div>
      </div>

      {/* View count overlay */}
      <div className="absolute top-4 right-4">
        <div className="bg-black bg-opacity-50 px-3 py-1 rounded-full">
          <span className="text-white text-sm">
            {formatCount(video.view_count)} views
          </span>
        </div>
      </div>
    </div>
  );
}
