import { useAuth } from "@getmocha/users-service/react";
import { Video, Users, Heart } from "lucide-react";

export default function LoginOverlay() {
  const { redirectToLogin } = useAuth();

  return (
    <div className="fixed inset-0 bg-black bg-opacity-90 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-gray-900 rounded-3xl p-8 max-w-sm w-full text-center shadow-2xl border border-gray-800">
        <div className="mb-8">
          <div className="w-16 h-16 bg-gradient-to-br from-pink-500 to-purple-600 rounded-2xl mx-auto mb-4 flex items-center justify-center">
            <Video className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-white mb-2">VidFlow</h1>
          <p className="text-gray-400">Create and share amazing videos</p>
        </div>

        <div className="space-y-4 mb-8">
          <div className="flex items-center space-x-3 text-left">
            <Video className="w-5 h-5 text-pink-500" />
            <span className="text-gray-300">Watch endless videos</span>
          </div>
          <div className="flex items-center space-x-3 text-left">
            <Heart className="w-5 h-5 text-red-500" />
            <span className="text-gray-300">Like your favorites</span>
          </div>
          <div className="flex items-center space-x-3 text-left">
            <Users className="w-5 h-5 text-blue-500" />
            <span className="text-gray-300">Follow creators</span>
          </div>
        </div>

        <button
          onClick={redirectToLogin}
          className="w-full bg-gradient-to-r from-pink-500 to-purple-600 text-white py-4 rounded-xl font-semibold text-lg hover:from-pink-600 hover:to-purple-700 transition-all duration-200 shadow-lg"
        >
          Sign in with Google
        </button>

        <p className="text-xs text-gray-500 mt-4">
          By signing in, you agree to our Terms of Service
        </p>
      </div>
    </div>
  );
}
