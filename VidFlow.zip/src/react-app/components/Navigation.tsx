import { Home, Plus, User } from "lucide-react";
import { useNavigate, useLocation } from "react-router";
import { useAuth } from "@getmocha/users-service/react";

export default function Navigation() {
  const navigate = useNavigate();
  const location = useLocation();
  const { user } = useAuth();

  if (!user) return null;

  const isActive = (path: string) => location.pathname === path;

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-black border-t border-gray-800 z-40">
      <div className="max-w-md mx-auto flex items-center justify-around py-2">
        <button
          onClick={() => navigate("/")}
          className={`flex flex-col items-center p-3 rounded-lg transition-colors ${
            isActive("/") ? "text-white" : "text-gray-500"
          }`}
        >
          <Home className="w-6 h-6 mb-1" />
          <span className="text-xs">Home</span>
        </button>

        <button className="flex flex-col items-center p-3 rounded-lg text-gray-500">
          <div className="w-8 h-8 bg-pink-500 rounded-lg flex items-center justify-center mb-1">
            <Plus className="w-5 h-5 text-white" />
          </div>
          <span className="text-xs">Create</span>
        </button>

        <button
          onClick={() => navigate("/profile")}
          className={`flex flex-col items-center p-3 rounded-lg transition-colors ${
            isActive("/profile") ? "text-white" : "text-gray-500"
          }`}
        >
          <User className="w-6 h-6 mb-1" />
          <span className="text-xs">Profile</span>
        </button>
      </div>
    </div>
  );
}
