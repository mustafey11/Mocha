import { useEffect, useState, useCallback } from "react";
import VideoPlayer from "./VideoPlayer";
import type { VideoWithProfile } from "@/shared/types";

export default function VideoFeed() {
  const [videos, setVideos] = useState<VideoWithProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [currentIndex, setCurrentIndex] = useState(0);

  const fetchVideos = useCallback(async () => {
    try {
      const response = await fetch("/api/videos?limit=20", {
        credentials: "include",
      });
      const data = await response.json();
      
      // Add some sample videos if none exist
      if (data.length === 0) {
        const sampleVideos = [
          {
            id: 1,
            user_id: "sample1",
            title: "Amazing Dance Moves",
            description: "Check out these sick moves! 🔥 #dance #viral",
            video_url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
            thumbnail_url: "https://images.unsplash.com/photo-1547036967-23d11aacaee0?w=400&h=600&fit=crop",
            view_count: 12500,
            like_count: 890,
            duration_seconds: 15,
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString(),
            is_liked: false,
            profile: {
              id: 1,
              user_id: "sample1",
              username: "dancer_pro",
              display_name: "Alex Chen",
              bio: "Professional dancer 💃",
              avatar_url: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face",
              follower_count: 45600,
              following_count: 234,
              video_count: 42,
              created_at: new Date().toISOString(),
              updated_at: new Date().toISOString(),
            }
          },
          {
            id: 2,
            user_id: "sample2",
            title: "Cooking Magic",
            description: "60-second pasta recipe that will blow your mind! 🍝 #cooking #recipe",
            video_url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
            thumbnail_url: "https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=400&h=600&fit=crop",
            view_count: 23400,
            like_count: 1200,
            duration_seconds: 60,
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString(),
            is_liked: false,
            profile: {
              id: 2,
              user_id: "sample2",
              username: "chef_maria",
              display_name: "Maria Rodriguez",
              bio: "Chef & Food Artist 👩‍🍳",
              avatar_url: "https://images.unsplash.com/photo-1494790108755-2616b612b789?w=150&h=150&fit=crop&crop=face",
              follower_count: 89200,
              following_count: 567,
              video_count: 156,
              created_at: new Date().toISOString(),
              updated_at: new Date().toISOString(),
            }
          },
          {
            id: 3,
            user_id: "sample3",
            title: "Nature Vibes",
            description: "Morning hike in the mountains 🏔️ #nature #hiking #peaceful",
            video_url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
            thumbnail_url: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=400&h=600&fit=crop",
            view_count: 7800,
            like_count: 456,
            duration_seconds: 30,
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString(),
            is_liked: false,
            profile: {
              id: 3,
              user_id: "sample3",
              username: "mountain_explorer",
              display_name: "Jake Thompson",
              bio: "Adventure seeker 🏕️",
              avatar_url: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face",
              follower_count: 12300,
              following_count: 890,
              video_count: 67,
              created_at: new Date().toISOString(),
              updated_at: new Date().toISOString(),
            }
          }
        ];
        setVideos(sampleVideos);
      } else {
        setVideos(data);
      }
    } catch (error) {
      console.error("Failed to fetch videos:", error);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchVideos();
  }, [fetchVideos]);

  const handleScroll = useCallback((e: React.UIEvent<HTMLDivElement>) => {
    const container = e.currentTarget;
    const scrollTop = container.scrollTop;
    const itemHeight = container.clientHeight;
    const newIndex = Math.round(scrollTop / itemHeight);
    
    if (newIndex !== currentIndex && newIndex >= 0 && newIndex < videos.length) {
      setCurrentIndex(newIndex);
    }
  }, [currentIndex, videos.length]);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen bg-black">
        <div className="animate-pulse">
          <div className="w-8 h-8 bg-white rounded-full opacity-20"></div>
        </div>
      </div>
    );
  }

  if (videos.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-screen bg-black text-white p-8">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-4">No videos yet</h2>
          <p className="text-gray-400">Be the first to share a video!</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 relative">
      <div 
        className="h-full overflow-y-auto snap-y snap-mandatory scrollbar-hide"
        onScroll={handleScroll}
        style={{ scrollBehavior: 'smooth' }}
      >
        {videos.map((video, index) => (
          <div key={video.id} className="h-screen snap-start">
            <VideoPlayer 
              video={video} 
              isActive={index === currentIndex}
              onUpdateVideo={(updatedVideo) => {
                setVideos(prev => prev.map(v => v.id === updatedVideo.id ? updatedVideo : v));
              }}
            />
          </div>
        ))}
      </div>
    </div>
  );
}
