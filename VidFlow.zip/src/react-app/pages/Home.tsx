import { useAuth } from "@getmocha/users-service/react";
import VideoFeed from "@/react-app/components/VideoFeed";
import LoginOverlay from "@/react-app/components/LoginOverlay";
import Navigation from "@/react-app/components/Navigation";
import { useEffect } from "react";

export default function Home() {
  const { user, isPending } = useAuth();

  useEffect(() => {
    // Add font
    const link = document.createElement('link');
    link.href = 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap';
    link.rel = 'stylesheet';
    document.head.appendChild(link);
    
    return () => {
      document.head.removeChild(link);
    };
  }, []);

  if (isPending) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-black">
        <div className="animate-pulse">
          <div className="w-8 h-8 bg-white rounded-full opacity-20"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-white font-inter relative">
      {!user && <LoginOverlay />}
      
      <div className="flex flex-col h-screen">
        <VideoFeed />
        <Navigation />
      </div>
    </div>
  );
}
