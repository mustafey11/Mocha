import { useAuth } from "@getmocha/users-service/react";
import { useNavigate } from "react-router";
import { useEffect, useState } from "react";
import { ArrowLeft, LogOut, Edit3 } from "lucide-react";
import type { UserProfile } from "@/shared/types";

export default function Profile() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) {
      navigate("/");
      return;
    }

    const fetchProfile = async () => {
      try {
        const response = await fetch("/api/profiles", {
          credentials: "include",
        });
        const data = await response.json();
        setProfile(data);
      } catch (error) {
        console.error("Failed to fetch profile:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchProfile();
  }, [user, navigate]);

  const handleLogout = async () => {
    await logout();
    navigate("/");
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-black text-white flex items-center justify-center">
        <div className="animate-pulse">
          <div className="w-8 h-8 bg-white rounded-full opacity-20"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-white">
      <div className="max-w-md mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-800">
          <button onClick={() => navigate("/")} className="p-2">
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h1 className="text-lg font-semibold">Profile</h1>
          <button onClick={handleLogout} className="p-2">
            <LogOut className="w-6 h-6" />
          </button>
        </div>

        {/* Profile Info */}
        <div className="p-6">
          <div className="flex flex-col items-center mb-8">
            <div className="relative mb-4">
              <img
                src={profile?.avatar_url || user?.google_user_data.picture || "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face"}
                alt="Profile"
                className="w-24 h-24 rounded-full object-cover border-2 border-gray-700"
              />
              <button className="absolute bottom-0 right-0 w-8 h-8 bg-pink-500 rounded-full flex items-center justify-center">
                <Edit3 className="w-4 h-4" />
              </button>
            </div>
            
            <h2 className="text-xl font-bold mb-1">
              {profile?.display_name || user?.google_user_data.name || "User"}
            </h2>
            
            {profile?.username && (
              <p className="text-gray-400 mb-2">@{profile.username}</p>
            )}
            
            {profile?.bio && (
              <p className="text-center text-gray-300 mb-4">{profile.bio}</p>
            )}

            {/* Stats */}
            <div className="flex space-x-8">
              <div className="text-center">
                <div className="text-xl font-bold">{profile?.following_count || 0}</div>
                <div className="text-sm text-gray-400">Following</div>
              </div>
              <div className="text-center">
                <div className="text-xl font-bold">{profile?.follower_count || 0}</div>
                <div className="text-sm text-gray-400">Followers</div>
              </div>
              <div className="text-center">
                <div className="text-xl font-bold">{profile?.video_count || 0}</div>
                <div className="text-sm text-gray-400">Videos</div>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="space-y-3">
            <button className="w-full py-3 bg-white text-black rounded-lg font-medium">
              Edit Profile
            </button>
            <button className="w-full py-3 border border-gray-600 rounded-lg font-medium">
              Share Profile
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
